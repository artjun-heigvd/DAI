package app;

public class UpdatePet {
    public String name = "";
    public int food = 0;

    public UpdatePet(String name, int food){
        this.name = name;
        this.food = food;
    }
}
